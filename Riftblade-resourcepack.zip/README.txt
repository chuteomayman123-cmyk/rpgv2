RPG Style More Weapons R — Paper resource pack
Minecraft Java 1.21.11, resource pack format 75.

Install this ZIP in .minecraft/resourcepacks and enable it under Options > Resource Packs.
The Paper plugin must be the updated build that assigns item models with the
rpgstylemoreweapons namespace. This pack has icons for all 55 item IDs supported
by the plugin. Weapon icons were rendered from the original JAR's cuboid
geometry and UV textures. Since those models depend on Forge/Geckolib, this pack
shows them as flat item icons and cannot reproduce animated 3D held models.
Armor icons appear in inventories but do not replace worn armor models. Ability
VFX from the original mod are not included.
