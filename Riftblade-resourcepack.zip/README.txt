Riftblade resource pack
For Minecraft Java 1.21.11 (resource pack format 75).
Install this ZIP in .minecraft/resourcepacks and enable it in Options > Resource Packs.
Requires the updated Paper plugin assigning the rpgstylemoreweapons:riftblade item model.
The energy highlight moves along the blade in a four-frame animated texture.
